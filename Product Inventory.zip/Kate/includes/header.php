<?php
// Start the session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    // If not logged in, redirect to index.php (Login page)
    header("location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Inventory System Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@600;700&family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    
    <style>
        /* --- GLOBAL TYPOGRAPHY & SYSTEM LAYOUT STYLES --- */
        body { 
            font-family: 'Poppins', sans-serif;
            background-color: #f4f6f9; 
            margin: 0;
            padding: 0;
            display: flex; 
            flex-direction: column; 
            min-height: 100vh;
        }
        h1, h2, h3, h4, h5, .sidebar-header h5 {
            font-family: 'Montserrat', sans-serif;
        }
        
        /* --- SIDEBAR STYLES --- */
        .sidebar {
            width: 250px;
            height: 100vh; 
            position: fixed; 
            top: 0;
            left: 0;
            background-color: #ffffff; 
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.05);
            padding: 20px 0;
            overflow-y: auto; 
            z-index: 1000;
        }
        .sidebar-header {
            text-align: center;
            padding: 10px 0 20px;
            border-bottom: 1px solid #eee;
            margin-bottom: 20px;
        }
        .profile-icon {
            font-size: 3.5rem;
            color: #007bff;
            margin-bottom: 10px;
        }
        .sidebar-header h5 {
            font-size: 1.1rem;
            font-weight: 600;
        }
        .sidebar-header p {
            font-size: 0.85rem;
            color: #6c757d;
        }
        .sidebar-menu li a {
            padding: 10px 20px;
            display: flex;
            align-items: center;
            color: #495057;
            text-decoration: none;
            transition: all 0.3s ease; /* Animation */
            font-weight: 400;
            border-left: 5px solid transparent;
        }
        .sidebar-menu li a:hover, .sidebar-menu li a.active {
            color: #007bff;
            background-color: #e9ecef;
            border-left: 5px solid #007bff;
            transform: translateX(3px); /* Small slide effect on hover */
        }
        .sidebar-menu li a i {
            margin-right: 10px;
            font-size: 1.1rem;
        }

        /* --- CONTENT WRAPPERS --- */
        .content-container {
            flex-grow: 1;
            margin-left: 250px; 
            width: calc(100% - 250px);
            display: flex;
            flex-direction: column;
        }
        .content-wrapper {
            padding: 30px;
            flex-grow: 1;
        }

        /* --- Content Card Styles (WITH ANIMATION) --- */
        .content-card {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 12px; 
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08); 
            margin-bottom: 30px;
            transition: transform 0.3s ease, box-shadow 0.3s ease; /* Animation */
        }
        .content-card:hover {
            transform: translateY(-3px); /* Subtle lift effect */
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
        }
        .content-card h2 {
            color: #007bff;
            border-bottom: 2px solid #e9ecef;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        
        /* --- Back Button Style Hover Animation --- */
        .back-btn-style {
            transition: all 0.2s; 
        }
        .back-btn-style:hover {
            transform: scale(1.03); 
        }

        /* --- MINIMAL FOOTER STYLES (from includes/header.php) --- */
.main-footer {
    background-color: #ffffff; 
    color: #6c757d;
    padding: 15px 30px;
    margin-left: 250px; 
    width: calc(100% - 250px);
    font-size: 0.85em;
    flex-shrink: 0; 
    border-top: 1px solid #dee2e6; 
    box-shadow: 0 -2px 5px rgba(0, 0, 0, 0.02);
}
.main-footer a {
    color: #495057; /* Darker link color */
    text-decoration: none;
    transition: color 0.2s;
    font-weight: 600;
}
.main-footer a:hover {
    color: #007bff; /* Primary color on hover */
}

/* Specific style for social icons */
.main-footer .social-icon {
    color: #6c757d !important; /* Muted color for social icons */
    font-size: 1.1em;
    transition: color 0.2s;
}
.main-footer .social-icon:hover {
    color: #007bff !important; /* Primary color on hover */
}

        /* --- DASHBOARD HERO SECTION STYLES --- */
        .dashboard-hero {
            background: linear-gradient(90deg, #007bff, #0056b3);
            color: #ffffff;
            padding: 40px;
            margin-bottom: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            position: relative;
            overflow: hidden;
            text-align: left;
        }
        .dashboard-hero h1 {
            color: #ffffff;
            font-size: 2.2rem;
            margin-bottom: 5px;
            font-weight: 700;
            padding-bottom: 0;
            border-bottom: none;
        }
        .dashboard-hero p {
            font-size: 1.1rem;
            opacity: 0.9;
            margin-bottom: 0;
            font-family: 'Poppins', sans-serif;
        }
        .dashboard-hero .hero-icon {
            position: absolute;
            right: 40px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 5rem;
            color: rgba(255, 255, 255, 0.15); 
        }
        
    </style>
</head>
<body>
<?php require_once "includes/sidebar.php"; ?>
<div class="content-container"> 
<div class="content-wrapper">