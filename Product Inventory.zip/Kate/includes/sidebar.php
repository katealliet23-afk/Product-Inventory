<div class="sidebar">
    <div class="sidebar-header">
        <i class="fas fa-user-circle fa-4x text-primary"></i> 
        <h5><?php echo htmlspecialchars($_SESSION["username"]); ?></h5>
        <p>Inventory Manager</p>
    </div>

    <ul class="sidebar-menu">
        <li class="<?php echo (basename($_SERVER['PHP_SELF']) == 'dashboard.php') ? 'active' : ''; ?>">
            <a href="dashboard.php">
                <span class="sidebar-link-content">
                    <i class="fas fa-cubes"></i> Products
                </span>
                <i class="fas fa-chevron-right"></i>
            </a>
        </li>
        <li class="<?php echo (basename($_SERVER['PHP_SELF']) == 'categories.php') ? 'active' : ''; ?>">
            <a href="categories.php">
                <span class="sidebar-link-content">
                    <i class="fas fa-tags"></i> Categories
                </span>
                <i class="fas fa-chevron-right"></i>
            </a>
        </li>
        <li class="<?php echo (basename($_SERVER['PHP_SELF']) == 'settings.php') ? 'active' : ''; ?>">
            <a href="settings.php">
                <span class="sidebar-link-content">
                    <i class="fas fa-cog"></i> Settings
                </span>
                <i class="fas fa-chevron-right"></i>
            </a>
        </li>
        <li>
            <a href="logout.php" onclick="return confirm('Are you sure you want to sign out fully?');">
                <span class="sidebar-link-content">
                    <i class="fas fa-sign-out-alt text-danger"></i> Sign Out
                </span>
            </a>
        </li>
    </ul>
</div>

<div class="content-wrapper">