</div> <footer class="main-footer">
        <div class="container-fluid">
            <div class="row align-items-center">
                <div class="col-md-6 text-center text-md-left">
                    &copy; <?php echo date("Y"); ?> **Inventory System Pro** | 
                    <a href="mailto:support@inventory.com" class="text-decoration-none">Support Email</a>
                    <span class="d-none d-md-inline"> | </span> 
                    <a href="#" class="text-decoration-none d-none d-md-inline">Privacy Policy</a>
                </div>

                <div class="col-md-6 text-center text-md-right">
                    <a href="#" class="social-icon text-secondary mx-2" title="Facebook"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" class="social-icon text-secondary mx-2" title="Twitter"><i class="fab fa-twitter"></i></a>
                    <a href="#" class="social-icon text-secondary mx-2" title="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
                </div>
            </div>
        </div>
    </footer>
    </div> <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
    <script>
        $(function () {
            $('[data-toggle="tooltip"]').tooltip()
        })
    </script>

</body>
</html>